
CREATE TABLE "Users" (

	"user_id" INTEGER,
	"name"	TEXT,
	"age"	INTEGER,
	"city"	TEXT,
	"email"	TEXT,
	"CNIC"	INTEGER,
	"address"	TEXT,
	PRIMARY KEY("user_id" AUTOINCREMENT)
);

COMMIT;
